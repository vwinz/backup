<?php
session_start(); // Start the session
include 'partials/connect.php'; // Include your database connection

// Check if the user is logged in
$is_logged_in = isset($_SESSION["user_id"]);
$user_id = $is_logged_in ? $_SESSION["user_id"] : null;
$username = $is_logged_in ? $_SESSION["username"] : "Guest"; // Use "Guest" if not logged in

$uploads = [];

// Fetch all uploads from the database
$stmt = $con->prepare("SELECT u.*, users.username FROM uploads u JOIN users ON u.user_id = users.user_id ORDER BY u.timestamp DESC");
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $uploads[] = $row;
}

$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($is_logged_in) { // Allow upload only if logged in
        if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
            $image_data = file_get_contents($_FILES['image']['tmp_name']);
            $text = isset($_POST['text']) ? $_POST['text'] : '';

            $stmt = $con->prepare("INSERT INTO uploads (user_id, image_data, text) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $user_id, $image_data, $text);

            if ($stmt->execute()) {
                // Optionally: You can redirect to the same page to refresh the uploads list
                header("Location: upload.php"); // Redirect to avoid form resubmission
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Error uploading file.";
        }
    } else {
        echo "You must be logged in to upload images."; // Message for users not logged in
    }
}

$con->close(); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload</title>
    <style>
        /* Reset some default styles */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        /* Center the container */
        h2 {
            text-align: center;
            margin-top: 20px;
            color: #333333; /* Add a color for the title */
        }

        .container {
            max-width: 600px; /* Limit the width */
            margin: 0 auto; /* Center the container */
            padding: 20px;
            background: white; /* White background for the form */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        /* Form styles */
        form {
            display: flex;
            flex-direction: column; /* Stack elements vertically */
        }

        /* Input styles */
        input[type="file"],
        textarea {
            padding: 10px; /* Padding inside input elements */
            margin: 10px 0; /* Margin between elements */
            border: 1px solid #ccc; /* Light border */
            border-radius: 4px; /* Rounded corners */
        }

        /* Button styles */
        button {
            background-color: #33333; /* Primary button color */
            color: grey; /* Text color */
            border: none; /* No border */
            padding: 10px; /* Padding */
            border-radius: 4px; /* Rounded corners */
            cursor: pointer; /* Pointer cursor */
            font-size: 16px; /* Font size */
        }

        button:hover {
            background-color: #333333; /* Darker shade on hover */
        }

        /* Message styles */
        p {
            text-align: center; /* Center align messages */
            color: #555; /* Message text color */
        }

        /* Styles for uploaded images */
        .upload-item img {
            max-width: 100%; /* Ensure the image does not exceed the width of its container */
            height: auto; /* Maintain aspect ratio */
            border-radius: 8px; /* Optional: adds rounded corners to images */
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1); /* Optional: adds a subtle shadow */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Updates</h2>
        <?php if ($is_logged_in): ?>
            <form method="post" action="upload.php" enctype="multipart/form-data">
                <input type="file" name="image" required>
                <textarea name="text" placeholder="Add a description..." required></textarea>
                <button type="submit">Upload</button>
            </form>
        <?php else: ?>
            <p>You must be logged in to upload images. Please <a href="login.php">log in</a> or <a href="signup.php">sign up</a>.</p>
        <?php endif; ?>

        <h2>Past Uploads</h2>
        <?php if (!empty($uploads)): ?>
            <?php foreach ($uploads as $upload): ?>
                <div class="upload-item">
                    <strong><?php echo htmlspecialchars($upload['username']); ?>:</strong>
                    <img src="data:image/jpeg;base64,<?php echo base64_encode($upload['image_data']); ?>" alt="Uploaded Image">
                    <p><?php echo htmlspecialchars($upload['text']); ?></p>
                    <small>Uploaded on: <?php echo htmlspecialchars($upload['timestamp']); ?></small>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No uploads found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
